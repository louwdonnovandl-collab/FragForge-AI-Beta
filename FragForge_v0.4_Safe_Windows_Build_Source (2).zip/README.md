# FragForge AI v0.4 — Rebuilt prototype

Gaming video editor for Windows desktop and Android Termux, free core features. **This is source code, not an APK or precompiled Windows EXE.** AI-powered premium services, mobile touch UI, and real-time timeline preview are not yet implemented. Scene-change highlight suggestions are a free heuristic, not a trained AI model.

## Windows
1. Install Python 3.10+ and FFmpeg; add both `ffmpeg` and `ffprobe` to PATH.
2. Unzip this package. Open PowerShell in its folder.
3. Run `python -m fragforge.gui` for the desktop editor.
4. Add videos, reorder clips, choose resolution/FPS, and render MP4.

## Android (Termux)
1. Install Termux and run `pkg update && pkg install python ffmpeg`.
2. Run `termux-setup-storage` and allow file access.
3. Unzip the project in your Termux home folder (or copy it from Downloads).
4. Run `python -m fragforge info /sdcard/Movies/clip.mp4`.
5. Edit `project_example.json` to point at your actual clips; render with:
   `python -m fragforge render project_example.json /sdcard/Movies/fragforge_output.mp4 --resolution 1080p --fps 60 --transition 0.35`
6. For scene-change suggestions: `python -m fragforge highlights /sdcard/Movies/clip.mp4`.

## Rendering details
FFmpeg `xfade` + `acrossfade` overlap clips; normalization to CFR, common dimensions, stereo 48kHz audio, H.264/AAC MP4. Missing audio streams receive silence. Transition=0 uses a concat filter. Rendering is CPU-based; 4K/120fps can be slow, particularly on phones. The renderer preserves video/audio continuity for valid inputs, but perfect output across every codec/device is not guaranteed.

## Limitations
The desktop GUI does not yet expose in/out trimming controls (edit project JSON for exact cuts). It does not provide a timeline preview, waveform, GPU acceleration, licensed premium AI features, or an Android APK. No payments or accounts are implemented. Avoid selecting output equal to any source. Test on your own media before relying on long projects.
