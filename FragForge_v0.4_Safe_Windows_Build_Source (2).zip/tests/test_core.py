import unittest
from unittest.mock import patch
from fragforge.core import build_command
class TestCore(unittest.TestCase):
    @patch('fragforge.core.binary',side_effect=lambda n:n)
    def test_crossfade(self,_):
        clips=[dict(path='a.mp4',start=0,end=2),dict(path='b.mp4',start=0,end=2)]
        cmd=build_command(clips,'out.mp4',transition=.35)
        filt=cmd[cmd.index('-filter_complex')+1]
        self.assertIn('xfade=transition=fade:duration=0.35:offset=1.650000',filt)
        self.assertIn('acrossfade=d=0.35',filt)
    @patch('fragforge.core.binary',side_effect=lambda n:n)
    def test_concat(self,_):
        cmd=build_command([dict(path='a',start=0,end=1),dict(path='b',start=0,end=1)],'out',transition=0)
        self.assertIn('concat=n=2:v=1:a=1',cmd[cmd.index('-filter_complex')+1])
    @patch('fragforge.core.binary',side_effect=lambda n:n)
    def test_invalid(self,_):
        with self.assertRaises(ValueError):build_command([dict(path='a',start=2,end=1)],'out')
if __name__=='__main__':unittest.main()
