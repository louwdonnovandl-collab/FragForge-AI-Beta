#define AppName "FragForge AI"
#define AppVersion "0.4"
[Setup]
AppId={{F40F50A4-0D4F-40C4-96D7-4E04E3DB4604}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={localappdata}\Programs\FragForge AI
DefaultGroupName=FragForge AI
OutputDir=dist
OutputBaseFilename=FragForge_AI_v0.4_Setup_UNSIGNED
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern
UninstallDisplayIcon={app}\FragForge.exe
[Files]
Source: "dist\FragForge\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
[Icons]
Name: "{group}\FragForge AI"; Filename: "{app}\FragForge.exe"
Name: "{autodesktop}\FragForge AI"; Filename: "{app}\FragForge.exe"; Tasks: desktopicon
[Tasks]
Name: desktopicon; Description: "Create a desktop shortcut"; Flags: unchecked
[Run]
Filename: "{app}\FragForge.exe"; Description: "Launch FragForge AI"; Flags: nowait postinstall skipifsilent
