# FragForge v0.4: safer Windows distribution

This package contains source and a GitHub Actions build recipe. It does NOT contain a compiled or signed installer. The previous VBS/PowerShell installer is intentionally excluded.

## Build (on a Windows GitHub Actions runner)
1. Create a private GitHub repository and upload the CONTENTS of this folder.
2. In Actions, manually run **Build Windows installer (unsigned)**.
3. Download the resulting build artifact from the workflow run.
4. The output is a normal Inno Setup EXE with bundled Python runtime and FFmpeg. No separate Python/FFmpeg install on end-user PCs.

## Smart App Control
An unsigned executable can still be blocked. Do not disable Smart App Control or use bypass commands. For reliable distribution, sign the EXE and preferably the bundled application binary using a trusted code-signing certificate or Microsoft Trusted Signing, and submit any false positive to Microsoft Security Intelligence. Do not share an unsigned build as if it were trusted.

## Notes
- The FFmpeg acquisition step depends on winget availability on the build runner; adjust if runner image changes.
- FFmpeg licensing and distribution requirements must be reviewed before public distribution.
- This is a prototype; rendering and Windows installation are NOT verified in this environment.
